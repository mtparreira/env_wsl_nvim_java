package br.dev.mtparreira.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Random;
import java.util.Set;
import java.util.HashSet;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import br.dev.mtparreira.demo.service.CalculatorSRV;

@SpringBootTest
public class CalculatorSRVTest {

    @Autowired
    private CalculatorSRV calculatorSRV;

    @Test
    public void testSomar() {
        Random r = new Random();
        Integer a = r.nextInt(10);
        Integer b = r.nextInt(10);
        Set<Integer> valoresAceitos = new HashSet<>();
        valoresAceitos.add(5);
        valoresAceitos.add(6);
        valoresAceitos.add(7);
        Integer resultado = calculatorSRV.somar(a,b);
        assertTrue(valoresAceitos.contains(resultado), "Resultado esperado: 5, 6 ou 7, mas foi " + resultado);
    }

    @Test
    public void testSomarOK() {
        Integer a = 4;
        Integer b = 4;
        Integer resultado = calculatorSRV.somar(a,b);
        assertEquals(8, resultado);
    }

    @Test
    public void testSomarNOK() {
        Integer a = 3;
        Integer b = 3;
        Integer resultado = calculatorSRV.somar(a,b);
        assertEquals(8, resultado);
    }

}
