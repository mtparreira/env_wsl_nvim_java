package br.dev.mtparreira.demo.service;

import org.springframework.stereotype.Service;

@Service
public class HelloWorldSRV {

    public String helloworld(String name) {
        return name;
    }

}
