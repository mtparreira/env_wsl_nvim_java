package br.dev.mtparreira.demo.service;

import org.springframework.stereotype.Service;

@Service
public class CalculatorSRV {

  public int somar(int a, int b) {
    return a + b;
  }

  public float media(int a, int b) {
    return a / b;
  }
}
