package br.dev.mtparreira.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.dev.mtparreira.demo.service.HelloWorldSRV;
import br.dev.mtparreira.demo.dto.UserDTO;

@RestController
@RequestMapping("/hello-world")
public class HelloWorldCTL {

    @Autowired
    private HelloWorldSRV helloWorldSRV;

    @GetMapping
    public String helloWorld() {
        return helloWorldSRV.helloworld("Olá mundo!");
    }

    @PostMapping
    public String helloworld(@RequestBody UserDTO body) {
        String palavra = "Mensagem";
        System.out.println(palavra + " POST entregue");
        return "Nome: " + body.getNome() + " | Email: " + body.getEmail();
    }
}
