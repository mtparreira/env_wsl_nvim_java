# Consumo da API
curl -X POST -H 'Content-Type: application/json' -d '{ "nome": "Marcos" , "email": "mtparreira@gmail.com" }' https://localhost:8080/hello-world
