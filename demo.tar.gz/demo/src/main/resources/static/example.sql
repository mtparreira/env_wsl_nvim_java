SELECT
  *
FROM
  tableName
WHERE
  field = 'abc';
